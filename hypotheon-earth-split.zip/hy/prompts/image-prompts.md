# Image prompts (one per scene) — save results as public/images/scene-0X.png (1080x1920)

**Negative prompt (all images):** cartoon, anime, illustration, low resolution, blurry, inconsistent Earth geometry, changing continent shapes, duplicate planets, extra moons, distorted planetary surfaces, random objects, flickering, unstable camera, excessive camera shake, unwanted text, subtitles, logos, watermark, low quality CGI.

Tip: generate Scene 01 first, then reuse it as a reference image for scenes 02, 03, 05, 06 so the Earth stays consistent.

## Scene 01
Ultra photorealistic planet Earth floating in deep space, beautiful blue oceans, realistic white clouds, sunlight illuminating the atmosphere, a tiny glowing golden fracture beginning to appear across the planet's surface, cinematic orbital photography, dramatic deep navy space, highly detailed planetary textures, vertical 9:16 composition, no text, no watermark.

## Scene 02
The same planet Earth viewed from outer space, an enormous glowing golden fracture stretching across the visible continents, bright orange light emerging from beneath the planetary crust, detailed clouds and oceans, realistic atmosphere, dramatic cinematic contrast, photorealistic planetary photography, vertical 9:16, no text, no watermark.

## Scene 03
The same Earth separating into two enormous hemispherical halves in deep space, both halves drifting apart, a glowing golden-orange interior visible between them, blue atmosphere surrounding each separated section, extremely wide cinematic science fiction composition, realistic planetary scale, detailed surface textures, dramatic lighting, vertical 9:16, no text.

## Scene 04
A photorealistic coastal megacity seen from a high aerial perspective, dramatic dark clouds covering the sky, rough ocean surface, distant glowing golden fracture visible across the horizon, cinematic environmental disaster atmosphere, realistic architecture, detailed ocean and cloud systems, moody lighting, vertical 9:16, no visible injuries, no text, no watermark.

## Scene 05
A gigantic Earth completely separated into two massive planetary halves, floating apart in deep space, glowing golden inner core visible between both halves, epic wide orbital shot, Earth dominates the composition, realistic blue atmosphere, detailed continents, cinematic lighting, deep black cosmic background, vertical 9:16, no text, no watermark.

## Scene 06
Two enormous separated halves of planet Earth floating in a vast dark universe, viewed from a very distant orbital perspective, subtle golden core glow, beautiful blue atmospheric rim light, tiny distant sunlight, emotional cinematic composition, minimalist deep space background with clear negative space for a final title and channel logo, vertical 9:16, no text, no watermark.
