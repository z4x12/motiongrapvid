# Video animation prompts — save results as public/videos/scene-0X.mp4 (use scene-0X.png as the start frame)

Durations: S01 5s · S02 6s · S03 7s · S04 8s · S05 10s · S06 9s. Use the same negative prompt as image-prompts.md.

## Scene 01
Slow cinematic camera push toward Earth. Clouds move subtly. A thin golden fracture gradually illuminates across the surface. Smooth orbital camera movement. Dramatic but realistic lighting.

## Scene 02
Slow orbital camera movement around Earth. The golden fracture expands visually with glowing energy and subtle floating particles. Maintain consistent planet geometry.

## Scene 03
Two planetary halves gradually drift apart in slow motion. The glowing inner core becomes more visible. Smooth cinematic camera pullback, realistic planetary movement, maintain consistent Earth appearance.

## Scene 04
Slow aerial tracking shot over the coastal city. Clouds move, ocean surface becomes rougher, distant golden light illuminates the horizon. Cinematic atmospheric movement.

## Scene 05
Camera slowly pulls away from the separated planet. Both halves rotate subtly while the glowing core remains visible. Epic cinematic scale, smooth movement, dramatic lighting.

## Scene 06
Very slow zoom-out into deep space. Both halves become smaller in frame. Atmospheric glow gradually fades into darkness. Leave clear visual space for the final logo reveal.
