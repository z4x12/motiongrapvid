import React from "react";
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile} from "remotion";
import {FilmGrain} from "./components/FilmGrain";
import {Subtitle} from "./components/Subtitle";
import {Scene01} from "./scenes/Scene01";
import {Scene02} from "./scenes/Scene02";
import {Scene03} from "./scenes/Scene03";
import {Scene04} from "./scenes/Scene04";
import {Scene05} from "./scenes/Scene05";
import {Scene06} from "./scenes/Scene06";
import {ASSETS, CLAMP, COLORS, SCENE_TIMING, SFX, SUBTITLES, TOTAL_FRAMES} from "./styles/theme";

const scenes = [Scene01, Scene02, Scene03, Scene04, Scene05, Scene06];

/** 1 while narration is present (with soft ramps), else 0. Drives music ducking. */
const duck = (f: number) =>
  SUBTITLES.reduce((m, c) => Math.max(m, interpolate(f, [c.from - 10, c.from, c.to, c.to + 15], [0, 1, 1, 0], CLAMP)), 0);

const musicVolume = (f: number) =>
  interpolate(duck(f), [0, 1], [0.38, 0.12]) * interpolate(f, [TOTAL_FRAMES - 120, TOTAL_FRAMES], [1, 0], CLAMP);

export const EarthSplitVideo: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: COLORS.navy}}>
    {scenes.map((Scene, i) => (
      <Sequence key={i} from={SCENE_TIMING[i].from} durationInFrames={SCENE_TIMING[i].duration} name={`Scene 0${i + 1}`}>
        <Scene />
      </Sequence>
    ))}
    <Subtitle />
    <FilmGrain />

    {ASSETS.voiceover && <Audio src={staticFile("audio/voiceover.mp3")} volume={1} />}
    {ASSETS.music && <Audio src={staticFile("audio/background-music.mp3")} volume={musicVolume} />}
    {ASSETS.sfx &&
      SFX.map((s) => (
        <Sequence key={s.file} from={s.from} durationInFrames={s.duration}>
          <Audio src={staticFile(`audio/sound-effects/${s.file}`)} volume={s.volume} />
        </Sequence>
      ))}
  </AbsoluteFill>
);
