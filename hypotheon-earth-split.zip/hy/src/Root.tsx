import React from "react";
import {Composition} from "remotion";
import {EarthSplitVideo} from "./EarthSplitVideo";
import {FPS, HEIGHT, TOTAL_FRAMES, WIDTH} from "./styles/theme";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="EarthSplit"
    component={EarthSplitVideo}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
