import React from "react";
import {AbsoluteFill, random, useCurrentFrame} from "remotion";
import {COLORS, HEIGHT, WIDTH} from "../styles/theme";

export const Backdrop: React.FC<{drift?: number; opacity?: number}> = ({drift = 0, opacity = 1}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 42%, ${COLORS.midnight} 0%, ${COLORS.navy} 58%, #030a14 100%)`}}>
      <svg width={WIDTH} height={HEIGHT} style={{opacity}}>
        <g transform={`translate(${-drift},0)`}>
          {Array.from({length: 150}, (_, i) => {
            const x = random(`sx${i}`) * (WIDTH + 300) - 100;
            const y = random(`sy${i}`) * HEIGHT;
            const r = 0.6 + random(`sr${i}`) * 1.5;
            const o = (0.3 + random(`so${i}`) * 0.6) * (0.75 + 0.25 * Math.sin(frame / 20 + i));
            return <circle key={i} cx={x} cy={y} r={r} fill={COLORS.white} opacity={o} />;
          })}
        </g>
      </svg>
    </AbsoluteFill>
  );
};

type PProps = {count?: number; color?: string; intensity?: number; seed?: string; speed?: number};

export const Particles: React.FC<PProps> = ({count = 28, color = COLORS.gold, intensity = 1, seed = "p", speed = 1}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: "none"}}>
      {Array.from({length: count}, (_, i) => {
        const x0 = random(`${seed}x${i}`) * WIDTH;
        const y0 = random(`${seed}y${i}`) * HEIGHT;
        const sp = (0.4 + random(`${seed}s${i}`)) * speed;
        const r = 1.5 + random(`${seed}r${i}`) * 3;
        const y = (((y0 - frame * sp * 1.4) % HEIGHT) + HEIGHT) % HEIGHT;
        const x = x0 + Math.sin(frame / 40 + i) * 14;
        const o = (0.25 + 0.5 * random(`${seed}o${i}`)) * intensity * (0.6 + 0.4 * Math.sin(frame / 12 + i));
        return (
          <div key={i} style={{position: "absolute", left: x, top: y, width: r * 2, height: r * 2, borderRadius: "50%", background: color, opacity: o, boxShadow: `0 0 ${r * 4}px ${color}`}} />
        );
      })}
    </AbsoluteFill>
  );
};
