import React from "react";
import {AbsoluteFill, Img, OffthreadVideo, interpolate, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import {ASSETS, CLAMP, COLORS} from "../styles/theme";

/** Dip-through-navy transition; never goes fully black (floor 0.25). */
export const SceneShell: React.FC<{children: React.ReactNode; fadeIn?: number; fadeOut?: number}> = ({children, fadeIn = 10, fadeOut = 8}) => {
  const frame = useCurrentFrame();
  const {durationInFrames: d} = useVideoConfig();
  const a = fadeIn > 0 ? interpolate(frame, [0, fadeIn], [0.25, 1], CLAMP) : 1;
  const b = fadeOut > 0 ? interpolate(frame, [d - fadeOut, d], [1, 0.25], CLAMP) : 1;
  return <AbsoluteFill style={{backgroundColor: COLORS.navy, opacity: Math.min(a, b)}}>{children}</AbsoluteFill>;
};

/** Uses generated video/image if enabled in ASSETS, otherwise the procedural fallback. */
export const SceneMedia: React.FC<{n: number; fallback: React.ReactNode}> = ({n, fallback}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const name = `scene-0${n}`;
  if (ASSETS.videos) {
    return (
      <AbsoluteFill>
        <OffthreadVideo src={staticFile(`videos/${name}.mp4`)} muted style={{width: "100%", height: "100%", objectFit: "cover"}} />
      </AbsoluteFill>
    );
  }
  if (ASSETS.images) {
    const z = interpolate(frame, [0, durationInFrames], [1, 1.12]);
    return (
      <AbsoluteFill>
        <Img src={staticFile(`images/${name}.png`)} style={{width: "100%", height: "100%", objectFit: "cover", transform: `scale(${z})`}} />
      </AbsoluteFill>
    );
  }
  return <>{fallback}</>;
};
