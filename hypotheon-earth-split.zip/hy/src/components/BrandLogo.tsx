import React from "react";
import {AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import {ASSETS, CLAMP, COLORS, EASE_OUT, FONT_BODY, FONT_HEADLINE} from "../styles/theme";

export const BrandLogo: React.FC<{delay?: number}> = ({delay = 0}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const f = frame - delay;
  const p = spring({frame: f, fps, config: {damping: 200}});
  const line = interpolate(f, [10, 50], [0, 1], {...CLAMP, easing: EASE_OUT});
  const sub = interpolate(f, [40, 70], [0, 1], CLAMP);
  return (
    <AbsoluteFill style={{alignItems: "center", justifyContent: "center", flexDirection: "column", opacity: p, transform: `scale(${0.94 + 0.06 * p})`}}>
      {ASSETS.logoImage ? (
        <Img src={staticFile("logo/hypotheon-logo.png")} style={{width: 360}} />
      ) : (
        <svg width={240} height={240} viewBox="0 0 240 240">
          <defs>
            <linearGradient id="bl-g" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor={COLORS.gold} />
              <stop offset="1" stopColor={COLORS.orange} />
            </linearGradient>
          </defs>
          <path d="M104 22 A98 98 0 0 0 104 218 L94 172 L110 128 L92 96 L108 58 Z" fill="rgba(16,43,70,.6)" stroke={COLORS.white} strokeWidth={5} strokeLinejoin="round" />
          <path d="M136 22 L122 62 L140 98 L120 130 L136 170 L126 218 A98 98 0 0 0 136 22 Z" fill="rgba(16,43,70,.6)" stroke="url(#bl-g)" strokeWidth={5} strokeLinejoin="round" />
        </svg>
      )}
      <div style={{marginTop: 30, fontFamily: FONT_HEADLINE, fontSize: 124, letterSpacing: "0.16em", color: COLORS.white, textShadow: "0 0 40px rgba(244,124,56,.35)"}}>
        HYPOTHEON<span style={{color: COLORS.orange}}> AI</span>
      </div>
      <div style={{width: 520 * line, height: 3, marginTop: 14, background: `linear-gradient(90deg, transparent, ${COLORS.gold}, transparent)`}} />
      <div style={{marginTop: 24, opacity: sub, fontFamily: FONT_BODY, fontSize: 30, letterSpacing: "0.32em", color: COLORS.white}}>ALTERNATE REALITIES</div>
    </AbsoluteFill>
  );
};
