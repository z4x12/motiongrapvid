import React from "react";
import {useCurrentFrame} from "remotion";
import {COLORS, CRACK} from "../styles/theme";

type Props = {size: number; progress?: number; intensity?: number};

/** Golden glowing fracture, drawn in the planet's local square (size x size). */
export const FractureGlow: React.FC<Props> = ({size, progress = 1, intensity = 1}) => {
  const frame = useCurrentFrame();
  if (progress <= 0.001) return null;
  const pulse = Math.min(1, intensity * (0.85 + 0.15 * Math.sin(frame / 5)));
  const d = CRACK.map(([x, y], i) => `${i ? "L" : "M"}${x * 1000} ${y * 1000}`).join(" ");
  const common = {
    d, pathLength: 1, fill: "none", strokeLinejoin: "round" as const,
    strokeDasharray: `${progress} 2`,
  };
  return (
    <div style={{position: "absolute", inset: 0, borderRadius: "50%", overflow: "hidden", pointerEvents: "none"}}>
      <svg width={size} height={size} viewBox="0 0 1000 1000" style={{opacity: pulse, mixBlendMode: "screen"}}>
        <defs>
          <filter id="fg-b1" filterUnits="userSpaceOnUse" x="-200" y="-200" width="1400" height="1400">
            <feGaussianBlur stdDeviation="24" />
          </filter>
          <filter id="fg-b2" filterUnits="userSpaceOnUse" x="-200" y="-200" width="1400" height="1400">
            <feGaussianBlur stdDeviation="7" />
          </filter>
        </defs>
        <path {...common} stroke={COLORS.orange} strokeWidth={64} filter="url(#fg-b1)" opacity={0.85} />
        <path {...common} stroke={COLORS.gold} strokeWidth={20} filter="url(#fg-b2)" />
        <path {...common} stroke="#FFF3D6" strokeWidth={6} />
      </svg>
    </div>
  );
};
