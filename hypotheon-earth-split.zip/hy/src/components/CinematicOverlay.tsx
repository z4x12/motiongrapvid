import React from "react";
import {AbsoluteFill} from "remotion";

type Props = {flare?: number; flareX?: number; flareY?: number};

export const CinematicOverlay: React.FC<Props> = ({flare = 0, flareX = 540, flareY = 980}) => (
  <AbsoluteFill style={{pointerEvents: "none"}}>
    <AbsoluteFill style={{background: "radial-gradient(ellipse at 50% 48%, rgba(0,0,0,0) 45%, rgba(3,8,18,.78) 100%)"}} />
    <AbsoluteFill
      style={{background: "linear-gradient(180deg, rgba(7,20,38,.35) 0%, rgba(7,20,38,0) 25%, rgba(7,20,38,0) 70%, rgba(7,20,38,.55) 100%)"}}
    />
    {flare > 0 && (
      <>
        <div
          style={{
            position: "absolute", left: flareX - 260, top: flareY - 260, width: 520, height: 520, opacity: flare * 0.55,
            background: "radial-gradient(circle, rgba(255,214,150,.85) 0%, rgba(244,124,56,.35) 30%, transparent 65%)",
            mixBlendMode: "screen",
          }}
        />
        <div
          style={{
            position: "absolute", left: flareX - 520, top: flareY - 2, width: 1040, height: 4, opacity: flare * 0.6,
            background: "linear-gradient(90deg, transparent, rgba(255,189,89,.9), transparent)", mixBlendMode: "screen",
          }}
        />
      </>
    )}
  </AbsoluteFill>
);
