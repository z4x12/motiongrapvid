import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {CLAMP, COLORS, FONT_BODY, SUBTITLES} from "../styles/theme";

/** Must be rendered at the composition root (absolute frames). */
export const Subtitle: React.FC = () => {
  const frame = useCurrentFrame();
  const cue = SUBTITLES.find((c) => frame >= c.from && frame < c.to);
  if (!cue) return null;
  const o = interpolate(frame, [cue.from, cue.from + 6, cue.to - 6, cue.to], [0, 1, 1, 0], CLAMP);
  return (
    <div style={{position: "absolute", left: 0, right: 0, bottom: 360, display: "flex", justifyContent: "center", opacity: o}}>
      <div
        style={{
          maxWidth: 920, padding: "16px 30px", borderRadius: 18, textAlign: "center",
          background: "rgba(7,20,38,.6)", color: COLORS.white, fontFamily: FONT_BODY, fontWeight: 600,
          fontSize: 50, lineHeight: 1.25, textShadow: "0 2px 10px rgba(0,0,0,.8)",
        }}
      >
        {cue.text}
      </div>
    </div>
  );
};
