import React from "react";
import {CRACK, COLORS} from "../styles/theme";
import {FractureGlow} from "./FractureGlow";

const BASE = 1000;

const clipFor = (side: "L" | "R") => {
  const pts: number[][] = side === "L" ? [[0, 0], ...CRACK, [0, 1]] : [...CRACK, [1, 1], [1, 0]];
  return `polygon(${pts.map(([x, y]) => `${x * 100}% ${y * 100}%`).join(",")})`;
};

const Layer: React.FC<{kind: "land" | "cloud"; offset: number}> = ({kind, offset}) => {
  const o = ((offset % BASE) + BASE) % BASE;
  const tile = (k: number) => (
    <svg key={k} width={BASE} height={BASE} style={{position: "absolute", left: k * BASE, top: 0}}>
      <defs>
        <filter id={`tex-${kind}`} x="0" y="0" width="100%" height="100%" colorInterpolationFilters="sRGB">
          {kind === "land" ? (
            <>
              <feTurbulence type="fractalNoise" baseFrequency="0.0045 0.007" numOctaves={5} seed={11} stitchTiles="stitch" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.20  0 0 0 0 0.34  0 0 0 0 0.19  9 0 0 0 -4.75" />
            </>
          ) : (
            <>
              <feTurbulence type="fractalNoise" baseFrequency="0.008 0.016" numOctaves={4} seed={4} stitchTiles="stitch" />
              <feColorMatrix type="matrix" values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  6 0 0 0 -2.7" />
            </>
          )}
        </filter>
      </defs>
      <rect width={BASE} height={BASE} fill="black" filter={`url(#tex-${kind})`} />
    </svg>
  );
  return (
    <div style={{position: "absolute", left: 0, top: 0, width: BASE * 2, height: BASE, transform: `translateX(${-o}px)`}}>
      {tile(0)}
      {tile(1)}
      {tile(2)}
    </div>
  );
};

const Disc: React.FC<{size: number; spin: number}> = ({size, spin}) => (
  <div
    style={{
      position: "absolute", inset: 0, borderRadius: "50%", overflow: "hidden",
      background: "radial-gradient(circle at 36% 30%, #2f86d1 0%, #165a9a 38%, #0b2f57 72%, #061428 100%)",
    }}
  >
    <div style={{position: "absolute", left: 0, top: 0, width: BASE * 2, height: BASE, transformOrigin: "0 0", transform: `scale(${size / BASE})`}}>
      <Layer kind="land" offset={spin} />
      <Layer kind="cloud" offset={spin * 1.3 + 300} />
    </div>
    <div
      style={{
        position: "absolute", inset: 0, borderRadius: "50%",
        background:
          "radial-gradient(circle at 30% 26%, rgba(255,255,255,.2), transparent 42%), radial-gradient(circle at 72% 62%, transparent 38%, rgba(2,6,16,.8) 100%)",
        boxShadow: `inset 0 0 ${size * 0.08}px rgba(140,205,255,.8)`,
      }}
    />
  </div>
);

type Props = {
  size: number; cx?: number; cy?: number; spin?: number; tilt?: number;
  crack?: number; split?: number; glow?: number; intensity?: number; opacity?: number;
};

/** Procedural Earth (fallback until generated imagery exists). Same look in every scene. */
export const Earth: React.FC<Props> = ({size, cx = 540, cy = 980, spin = 0, tilt = 0, crack = 0, split = 0, glow = 0, intensity = 1, opacity = 1}) => {
  const halves = split > 0.5;
  const gw = split * 2 + size * 0.3;
  return (
    <div style={{position: "absolute", left: cx - size / 2, top: cy - size / 2, width: size, height: size, transform: `rotate(${tilt}deg)`, opacity}}>
      {!halves && (
        <div style={{position: "absolute", inset: -size * 0.03, borderRadius: "50%", boxShadow: `0 0 ${size * 0.12}px ${size * 0.02}px rgba(80,160,255,.35)`}} />
      )}
      {halves && (
        <div
          style={{
            position: "absolute", left: (size - gw) / 2, top: size * 0.05, width: gw, height: size * 0.9, borderRadius: "50%",
            background: `radial-gradient(closest-side, rgba(255,240,190,${glow}) 0%, rgba(255,189,89,${0.85 * glow}) 25%, rgba(244,124,56,${0.55 * glow}) 55%, rgba(244,124,56,0) 100%)`,
            filter: `blur(${size * 0.025}px)`,
          }}
        />
      )}
      {halves ? (
        <>
          <div style={{position: "absolute", inset: 0, transform: `translateX(${-split}px)`, clipPath: clipFor("L")}}>
            <Disc size={size} spin={spin} />
            <FractureGlow size={size} intensity={intensity} />
          </div>
          <div style={{position: "absolute", inset: 0, transform: `translateX(${split}px)`, clipPath: clipFor("R")}}>
            <Disc size={size} spin={spin} />
            <FractureGlow size={size} intensity={intensity} />
          </div>
        </>
      ) : (
        <>
          <Disc size={size} spin={spin} />
          <FractureGlow size={size} progress={crack} intensity={intensity} />
        </>
      )}
      <div style={{display: "none", color: COLORS.gold}} />
    </div>
  );
};
