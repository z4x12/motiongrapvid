import React from "react";
import {interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {CLAMP, COLORS, FONT_HEADLINE} from "../styles/theme";

type Props = {text: string; highlight?: string[]; delay?: number; exitAt?: number; top?: number; size?: number};

export const Headline: React.FC<Props> = ({text, highlight = [], delay = 10, exitAt, top = 210, size = 118}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const out = exitAt === undefined ? 1 : interpolate(frame, [exitAt, exitAt + 18], [1, 0], CLAMP);
  return (
    <div
      style={{
        position: "absolute", left: 60, right: 60, top, textAlign: "center",
        fontFamily: FONT_HEADLINE, fontSize: size, lineHeight: 1.04, letterSpacing: 2,
        textTransform: "uppercase", opacity: out,
      }}
    >
      {text.split(" ").map((w, i) => {
        const p = spring({frame: frame - delay - i * 4, fps, config: {damping: 200}});
        const hl = highlight.includes(w);
        return (
          <span
            key={i}
            style={{
              display: "inline-block", marginRight: "0.28em", opacity: p,
              transform: `translateY(${(1 - p) * 40}px)`, filter: `blur(${(1 - p) * 10}px)`,
              color: hl ? COLORS.orange : COLORS.white,
              textShadow: hl ? "0 0 28px rgba(244,124,56,.6), 0 6px 24px rgba(0,0,0,.7)" : "0 6px 28px rgba(0,0,0,.75)",
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};
