import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {COLORS, FONT_BODY, HEIGHT, WIDTH} from "../styles/theme";

type Props = {cx?: number; cy?: number; radius?: number; opacity?: number; tag?: string};

export const ScientificHUD: React.FC<Props> = ({cx = 540, cy = 980, radius = 520, opacity = 1, tag = "ORBITAL VIEW"}) => {
  const frame = useCurrentFrame();
  const lat = (23.4 + frame * 0.021).toFixed(2);
  const lon = (-47.9 + frame * 0.13).toFixed(2);
  const label = {fontFamily: FONT_BODY, fontSize: 22, letterSpacing: "0.2em", color: COLORS.white, opacity: 0.75} as const;
  return (
    <AbsoluteFill style={{opacity: opacity * 0.9, pointerEvents: "none"}}>
      <svg width={WIDTH} height={HEIGHT}>
        <g transform={`rotate(${frame * 0.15} ${cx} ${cy})`}>
          <ellipse cx={cx} cy={cy} rx={radius * 1.18} ry={radius * 0.42} fill="none" stroke={COLORS.orange} strokeOpacity={0.5} strokeWidth={1.5} strokeDasharray="4 10" transform={`rotate(-18 ${cx} ${cy})`} />
          <ellipse cx={cx} cy={cy} rx={radius * 1.05} ry={radius * 0.3} fill="none" stroke={COLORS.white} strokeOpacity={0.18} strokeWidth={1} transform={`rotate(32 ${cx} ${cy})`} />
          <circle cx={cx} cy={cy} r={radius * 1.1} fill="none" stroke={COLORS.white} strokeOpacity={0.14} strokeWidth={1} />
          {Array.from({length: 36}, (_, i) => {
            const a = (i / 36) * Math.PI * 2;
            const r1 = radius * 1.1;
            const r2 = radius * (i % 3 === 0 ? 1.16 : 1.13);
            return <line key={i} x1={cx + Math.cos(a) * r1} y1={cy + Math.sin(a) * r1} x2={cx + Math.cos(a) * r2} y2={cy + Math.sin(a) * r2} stroke={COLORS.gold} strokeOpacity={0.5} strokeWidth={1.5} />;
          })}
        </g>
      </svg>
      <div style={{position: "absolute", left: 60, top: 110, ...label}}>{tag}</div>
      <div style={{position: "absolute", right: 60, top: 110, textAlign: "right", ...label, color: COLORS.gold}}>
        LAT {lat}° &nbsp; LON {lon}°
      </div>
      <div style={{position: "absolute", left: 60, top: 146, ...label, fontSize: 18, opacity: 0.55}}>FICTIONAL WHAT-IF SCENARIO · NOT A PREDICTION</div>
    </AbsoluteFill>
  );
};
