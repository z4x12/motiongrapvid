import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {Backdrop, Particles} from "../components/Backdrop";
import {CinematicOverlay} from "../components/CinematicOverlay";
import {Earth} from "../components/Earth";
import {Headline} from "../components/Headline";
import {SceneMedia, SceneShell} from "../components/SceneShell";
import {ScientificHUD} from "../components/ScientificHUD";
import {CLAMP, EASE_OUT} from "../styles/theme";

export const Scene03: React.FC = () => {
  const frame = useCurrentFrame();
  const zoom = interpolate(frame, [0, 210], [1, 0.78], CLAMP);
  const split = interpolate(frame, [15, 200], [0, 220], {...CLAMP, easing: EASE_OUT}) * zoom;
  const glow = interpolate(frame, [15, 200], [0.3, 1], CLAMP);
  return (
    <SceneShell>
      <SceneMedia
        n={3}
        fallback={
          <>
            <Backdrop drift={frame * 0.2} />
            <Earth size={900 * zoom} cy={990} spin={612 + frame * 1.1} tilt={-18} crack={1} split={split} glow={glow} intensity={1.2} />
            <Particles count={40} intensity={1} seed="s3" speed={1.4} />
          </>
        }
      />
      <ScientificHUD cy={990} radius={480} opacity={0.7} tag="ORBITAL VIEW · 03" />
      <Headline text="TWO HALVES. ONE PLANET." highlight={["ONE", "PLANET."]} delay={14} />
      <CinematicOverlay flare={glow} flareY={990} />
    </SceneShell>
  );
};
