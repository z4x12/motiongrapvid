import React from "react";
import {Easing, interpolate, useCurrentFrame} from "remotion";
import {Backdrop} from "../components/Backdrop";
import {CinematicOverlay} from "../components/CinematicOverlay";
import {Earth} from "../components/Earth";
import {Headline} from "../components/Headline";
import {SceneMedia, SceneShell} from "../components/SceneShell";
import {ScientificHUD} from "../components/ScientificHUD";
import {CLAMP, shake} from "../styles/theme";

export const Scene01: React.FC = () => {
  const frame = useCurrentFrame();
  const zoom = interpolate(frame, [0, 150], [0.78, 1.12], {...CLAMP, easing: Easing.inOut(Easing.cubic)});
  const crack = interpolate(frame, [70, 135], [0, 0.38], CLAMP);
  const s = shake(frame, 72, 18, 10);
  return (
    <SceneShell fadeIn={0}>
      <SceneMedia
        n={1}
        fallback={
          <>
            <Backdrop drift={frame * 0.15} />
            <div style={{position: "absolute", inset: 0, transform: `translate(${s.x}px,${s.y}px)`}}>
              <Earth size={800 * zoom} spin={frame * 1.2} tilt={-18} crack={crack} intensity={0.9} />
            </div>
          </>
        }
      />
      <ScientificHUD radius={420 * zoom} opacity={0.6} tag="ORBITAL VIEW · 01" />
      <Headline text="WHAT IF EARTH SPLIT IN HALF?" highlight={["SPLIT"]} delay={12} />
      <CinematicOverlay />
    </SceneShell>
  );
};
