import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {Backdrop, Particles} from "../components/Backdrop";
import {CinematicOverlay} from "../components/CinematicOverlay";
import {Earth} from "../components/Earth";
import {Headline} from "../components/Headline";
import {SceneMedia, SceneShell} from "../components/SceneShell";
import {ScientificHUD} from "../components/ScientificHUD";
import {CLAMP, EASE_IO} from "../styles/theme";

export const Scene02: React.FC = () => {
  const frame = useCurrentFrame();
  const crack = interpolate(frame, [8, 120], [0.38, 1], {...CLAMP, easing: EASE_IO});
  const intensity = interpolate(frame, [0, 140], [0.7, 1.2], CLAMP);
  const scale = interpolate(frame, [0, 180], [1, 1.06], CLAMP);
  return (
    <SceneShell>
      <SceneMedia
        n={2}
        fallback={
          <>
            <Backdrop drift={frame * 0.3} />
            <Earth size={900 * scale} cy={990} spin={180 + frame * 2.4} tilt={-18 + Math.sin(frame / 60) * 2} crack={crack} intensity={intensity} />
            <Particles count={26} intensity={0.8} seed="s2" />
          </>
        }
      />
      <ScientificHUD cy={990} radius={500} tag="ORBITAL VIEW · 02" />
      <Headline text="A CRACK ACROSS EARTH" highlight={["CRACK"]} delay={14} />
      <CinematicOverlay />
    </SceneShell>
  );
};
