import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {Backdrop} from "../components/Backdrop";
import {BrandLogo} from "../components/BrandLogo";
import {CinematicOverlay} from "../components/CinematicOverlay";
import {Earth} from "../components/Earth";
import {Headline} from "../components/Headline";
import {SceneMedia, SceneShell} from "../components/SceneShell";
import {CLAMP, EASE_IO} from "../styles/theme";

export const Scene06: React.FC = () => {
  const frame = useCurrentFrame();
  const z = interpolate(frame, [0, 190], [1, 0.5], {...CLAMP, easing: EASE_IO});
  const planetOpacity = interpolate(frame, [110, 170], [1, 0], CLAMP);
  const dark = interpolate(frame, [100, 160], [0, 0.97], CLAMP);
  return (
    <SceneShell fadeOut={0}>
      <SceneMedia
        n={6}
        fallback={
          <>
            <Backdrop drift={frame * 0.1} opacity={interpolate(frame, [120, 200], [1, 0.3], CLAMP)} />
            <Earth size={432 * z} cy={900} spin={1000 + frame * 0.4} tilt={-18} crack={1} split={135 * z} glow={0.9 * planetOpacity} opacity={planetOpacity} />
          </>
        }
      />
      <AbsoluteFill style={{backgroundColor: "#030812", opacity: dark}} />
      <Headline text="THE END OF OUR WORLD?" highlight={["WORLD?"]} delay={6} exitAt={100} />
      <CinematicOverlay />
      <BrandLogo delay={160} />
    </SceneShell>
  );
};
