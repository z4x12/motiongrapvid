import React from "react";
import {AbsoluteFill, interpolate, random, useCurrentFrame} from "remotion";
import {Particles} from "../components/Backdrop";
import {CinematicOverlay} from "../components/CinematicOverlay";
import {Headline} from "../components/Headline";
import {SceneMedia, SceneShell} from "../components/SceneShell";
import {CLAMP, COLORS, HEIGHT, WIDTH} from "../styles/theme";

const HORIZON = 790;
const NEAR = Array.from({length: 30}, (_, i) => ({x: i * 46 - 60, w: 34 + random(`bw${i}`) * 40, h: 260 + random(`bh${i}`) * 520}));
const FAR = Array.from({length: 40}, (_, i) => ({x: i * 36 - 80, w: 26 + random(`fw${i}`) * 30, h: 90 + random(`fh${i}`) * 200}));
const CLOUDS = Array.from({length: 8}, (_, i) => ({
  x: random(`cx${i}`) * 2500, y: random(`cy${i}`) * 900 + 30, w: 700 + random(`cw${i}`) * 600,
  h: 200 + random(`ch${i}`) * 220, s: 0.3 + random(`cs${i}`) * 0.7, o: 0.5 + random(`co${i}`) * 0.4,
}));
const building = "repeating-linear-gradient(90deg, transparent 0 7px, #0a1424 7px 12px), repeating-linear-gradient(0deg, rgba(255,200,110,.45) 0 5px, transparent 5px 16px), #0a1424";

const City: React.FC = () => {
  const frame = useCurrentFrame();
  const amp = interpolate(frame, [0, 240], [3, 16], CLAMP);
  const pulse = 0.8 + 0.2 * Math.sin(frame / 7);
  const horizonPath = Array.from({length: 19}, (_, i) => `${i ? "L" : "M"}${i * 60} ${HORIZON + Math.sin(i * 2.3) * 7}`).join(" ");
  return (
    <AbsoluteFill>
      <div style={{position: "absolute", left: 0, top: 0, width: WIDTH, height: HORIZON + 10, background: "linear-gradient(180deg,#050b16 0%,#14202f 40%,#2a2f38 100%)"}} />
      <div style={{position: "absolute", left: 0, top: HORIZON, width: WIDTH, height: HEIGHT - HORIZON, background: "linear-gradient(180deg,#0e2e4c 0%,#06182c 70%,#04101f 100%)"}} />
      <div style={{position: "absolute", left: 0, top: HORIZON - 200, width: WIDTH, height: 400, opacity: 0.75 * pulse, background: "radial-gradient(ellipse at 50% 50%, rgba(255,189,89,.8) 0%, rgba(244,124,56,.4) 30%, transparent 65%)"}} />
      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        <defs>
          <filter id="hz-b" filterUnits="userSpaceOnUse" x="-50" y="600" width="1200" height="400"><feGaussianBlur stdDeviation="6" /></filter>
        </defs>
        <path d={horizonPath} stroke={COLORS.gold} strokeWidth={10} fill="none" filter="url(#hz-b)" opacity={pulse} />
        <path d={horizonPath} stroke="#FFF3D6" strokeWidth={2.5} fill="none" opacity={0.9} />
        {Array.from({length: 16}, (_, i) => {
          const y = HORIZON + 14 + Math.pow(i / 15, 1.6) * 700;
          const d = Array.from({length: 20}, (_, k) => `${k ? "L" : "M"}${k * 60 - 20} ${y + Math.sin(k * 0.7 + frame * 0.12 + i) * amp * (0.4 + i / 15)}`).join(" ");
          return <path key={i} d={d} stroke="rgba(170,210,240,.16)" strokeWidth={2} fill="none" />;
        })}
      </svg>
      {CLOUDS.map((c, i) => (
        <div
          key={i}
          style={{
            position: "absolute", left: ((c.x + frame * c.s) % 2500) - 1400, top: c.y, width: c.w, height: c.h, borderRadius: "50%",
            background: `radial-gradient(ellipse, rgba(22,30,44,${c.o}) 0%, transparent 70%)`, filter: "blur(30px)",
          }}
        />
      ))}
      <div style={{position: "absolute", inset: 0, transform: `translateX(${-frame * 0.6}px) scale(1.06)`}}>
        {FAR.map((b, i) => (
          <div key={`f${i}`} style={{position: "absolute", left: b.x, top: 1580 - b.h, width: b.w, height: b.h, background: building, opacity: 0.8}} />
        ))}
        {NEAR.map((b, i) => (
          <div key={`n${i}`} style={{position: "absolute", left: b.x, top: HEIGHT - b.h, width: b.w, height: b.h, background: building}} />
        ))}
      </div>
      <div style={{position: "absolute", left: 0, top: 1150, width: WIDTH, height: 770, background: "linear-gradient(180deg, transparent, rgba(16,43,70,.5))", opacity: 0.6 + 0.2 * Math.sin(frame / 30)}} />
    </AbsoluteFill>
  );
};

export const Scene04: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <SceneShell>
      <SceneMedia
        n={4}
        fallback={
          <>
            <City />
            <Particles count={40} color="#B8D4F0" intensity={0.35} seed="s4" speed={2} />
          </>
        }
      />
      <Headline text="THE WORLD IS CHANGING" highlight={["CHANGING"]} delay={14} />
      <CinematicOverlay />
      <div style={{display: "none"}}>{frame}</div>
    </SceneShell>
  );
};
