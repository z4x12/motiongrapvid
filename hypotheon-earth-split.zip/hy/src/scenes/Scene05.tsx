import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {Backdrop, Particles} from "../components/Backdrop";
import {CinematicOverlay} from "../components/CinematicOverlay";
import {Earth} from "../components/Earth";
import {Headline} from "../components/Headline";
import {SceneMedia, SceneShell} from "../components/SceneShell";
import {ScientificHUD} from "../components/ScientificHUD";
import {CLAMP, EASE_IO} from "../styles/theme";

export const Scene05: React.FC = () => {
  const frame = useCurrentFrame();
  const zoom = interpolate(frame, [0, 300], [1.1, 0.72], {...CLAMP, easing: EASE_IO});
  const hud = interpolate(frame, [0, 220], [0.8, 0], CLAMP);
  return (
    <SceneShell>
      <SceneMedia
        n={5}
        fallback={
          <>
            <Backdrop drift={frame * 0.2} />
            <Earth size={600 * zoom} cy={990} spin={900 + frame * 0.6} tilt={-18 + frame * 0.02} crack={1} split={187 * zoom} glow={1} intensity={1.1} />
            <Particles count={30} intensity={0.7} seed="s5" />
          </>
        }
      />
      <ScientificHUD cy={990} radius={430} opacity={hud} tag="ORBITAL VIEW · 05" />
      <Headline text="WOULD HUMANITY SURVIVE?" highlight={["SURVIVE?"]} delay={40} />
      <CinematicOverlay flare={0.5} flareY={990} />
    </SceneShell>
  );
};
