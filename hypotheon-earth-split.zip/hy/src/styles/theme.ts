import {Easing} from "remotion";
import {loadFont as loadAnton} from "@remotion/google-fonts/Anton";
import {loadFont as loadInter} from "@remotion/google-fonts/Inter";

export const COLORS = {
  navy: "#071426",
  midnight: "#102B46",
  orange: "#F47C38",
  gold: "#FFBD59",
  white: "#F4F4F4",
} as const;

export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const TOTAL_FRAMES = 1350;

export const FONT_HEADLINE = loadAnton().fontFamily;
export const FONT_BODY = loadInter("normal", {weights: ["600"], subsets: ["latin"]}).fontFamily;

export const SCENE_TIMING = [
  {from: 0, duration: 150},
  {from: 150, duration: 180},
  {from: 330, duration: 210},
  {from: 540, duration: 240},
  {from: 780, duration: 300},
  {from: 1080, duration: 270},
];

/**
 * Asset switches. Everything is false because NO external assets were generated.
 * Flip a flag to true only after the matching files exist in /public.
 */
export const ASSETS: {
  images: boolean; // public/images/scene-01..06.png
  videos: boolean; // public/videos/scene-01..06.mp4 (wins over images)
  voiceover: boolean; // public/audio/voiceover.mp3
  music: boolean; // public/audio/background-music.mp3
  sfx: boolean; // public/audio/sound-effects/*.mp3
  logoImage: boolean; // public/logo/hypotheon-logo.png
} = {images: false, videos: false, voiceover: false, music: false, sfx: false, logoImage: false};

export const SFX = [
  {file: "rumble.mp3", from: 0, duration: 150, volume: 0.5},
  {file: "impact.mp3", from: 95, duration: 60, volume: 0.6},
  {file: "crack.mp3", from: 160, duration: 120, volume: 0.6},
  {file: "boom.mp3", from: 345, duration: 90, volume: 0.7},
  {file: "ocean-wind.mp3", from: 548, duration: 240, volume: 0.35},
  {file: "drone.mp3", from: 800, duration: 300, volume: 0.4},
  {file: "final-hit.mp3", from: 1090, duration: 120, volume: 0.6},
];

/** Absolute-frame subtitle cues (max two lines each). Also drive music ducking. */
export const SUBTITLES = [
  {from: 12, to: 80, text: "Imagine waking up tomorrow..."},
  {from: 82, to: 145, text: "and discovering Earth has split in half."},
  {from: 162, to: 322, text: "From space, a massive crack stretches across our planet."},
  {from: 345, to: 440, text: "Two enormous halves begin drifting apart,"},
  {from: 442, to: 535, text: "revealing a glowing core beneath the surface."},
  {from: 556, to: 640, text: "The oceans shift. The atmosphere changes."},
  {from: 645, to: 772, text: "And the familiar world we once knew begins to disappear."},
  {from: 800, to: 940, text: "From orbit, Earth no longer looks like home."},
  {from: 1095, to: 1195, text: "Could humanity survive on a planet torn in two?"},
  {from: 1205, to: 1295, text: "Or would this be the end of our world?"},
];

/** Shared fracture line (normalised 0..1, top to bottom). Used by the planet and the glow. */
export const CRACK: [number, number][] = [
  [0.52, 0], [0.46, 0.12], [0.55, 0.25], [0.48, 0.38], [0.57, 0.5],
  [0.47, 0.63], [0.54, 0.76], [0.46, 0.88], [0.51, 1],
];

export const CLAMP = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
export const EASE_OUT = Easing.out(Easing.cubic);
export const EASE_IO = Easing.inOut(Easing.cubic);

export const shake = (frame: number, start: number, duration: number, amp: number) => {
  const t = (frame - start) / duration;
  if (t < 0 || t > 1) return {x: 0, y: 0};
  const d = (1 - t) * (1 - t);
  return {x: Math.sin(frame * 2.7) * amp * d, y: Math.cos(frame * 3.3) * amp * d};
};
