# Hypotheon AI — What If Earth Split in Half? (Remotion)

45 s · 1080×1920 · 30 fps · 1350 frames · 6 scenes.

## Run
```
npm install
npm run dev        # Remotion Studio preview
npm run typecheck
npm run render     # -> out/hypotheon-earth-split.mp4
```
Fonts (Anton, Inter) are loaded via @remotion/google-fonts, so the first run needs internet.

## Status of assets (nothing external was generated)
| Item | State |
|---|---|
| Earth, fracture, city, HUD, grain, logo mark | Procedural (code) — works out of the box |
| public/images/scene-0X.png | MISSING — prompts in prompts/image-prompts.md |
| public/videos/scene-0X.mp4 | MISSING — prompts in prompts/video-prompts.md |
| public/audio/voiceover.mp3 | MISSING — record/generate the narration (45 s timeline, pauses matching the subtitle cues in src/styles/theme.ts) |
| public/audio/background-music.mp3 | MISSING — use licensed/original music; auto-ducks under narration |
| public/audio/sound-effects/*.mp3 | MISSING — rumble, impact, crack, boom, ocean-wind, drone, final-hit |
| public/logo/hypotheon-logo.png | MISSING — a code-drawn mark is used instead |

## Switching to real assets
Put the files in `public/` and set the matching flag to `true` in `ASSETS` (src/styles/theme.ts).
Videos take priority over images; images over the procedural fallback. Headlines, subtitles, HUD labels,
overlay, grain and the final branding stay on top in every mode.

## Notes
- Subtitle timing lives in `SUBTITLES` (theme.ts) and also drives music ducking. Re-time it to the real voice-over.
- The video is framed as a fictional scenario (HUD label), not a scientific prediction.
- Procedural Earth uses SVG turbulence filters: rendering is slower than normal; use `--concurrency` if needed.
